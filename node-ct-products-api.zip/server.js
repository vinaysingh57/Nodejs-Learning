#!/usr/bin/env node

/**
 * Commercetools Products API Server
 * Main entry point for the application
 */

const { createApp } = require('./src/app');
const { config, validateConfig } = require('./src/config');
const { testCommercetoolsConnection } = require('./src/config/commercetools');

/**
 * Start the server
 */
async function startServer() {
  try {
    // Validate configuration
    console.log('🔧 Validating configuration...');
    validateConfig();

    // Test Commercetools connection
    console.log('🔗 Testing Commercetools connection...');
    const isConnected = await testCommercetoolsConnection();
    
    if (!isConnected) {
      console.error('❌ Failed to connect to Commercetools. Check your configuration.');
      process.exit(1);
    }

    // Create Express app
    const app = createApp();

    // Start server
    const server = app.listen(config.server.port, config.server.host, () => {
      console.log('==================================================');
      console.log('🚀 Commercetools Products API Server Started!');
      console.log('==================================================');
      console.log(`📍 Server: http://${config.server.host}:${config.server.port}`);
      console.log(`🌍 Environment: ${config.server.nodeEnv}`);
      console.log(`📊 Health Check: http://${config.server.host}:${config.server.port}/health`);
      console.log(`📚 API Base: http://${config.server.host}:${config.server.port}/api/v1`);
      console.log('==================================================');
    });

    // Graceful shutdown handling
    process.on('SIGTERM', () => {
      console.log('📱 SIGTERM received. Starting graceful shutdown...');
      gracefulShutdown(server);
    });

    process.on('SIGINT', () => {
      console.log('📱 SIGINT received. Starting graceful shutdown...');
      gracefulShutdown(server);
    });

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('💥 Uncaught Exception:', error);
      gracefulShutdown(server);
    });

    // Handle unhandled promise rejections
    process.on('unhandledRejection', (reason, promise) => {
      console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
      gracefulShutdown(server);
    });

  } catch (error) {
    console.error('💥 Failed to start server:', error);
    process.exit(1);
  }
}

/**
 * Graceful shutdown
 * @param {Object} server - HTTP server instance
 */
function gracefulShutdown(server) {
  console.log('⏳ Closing HTTP server...');
  
  server.close((err) => {
    if (err) {
      console.error('❌ Error during server shutdown:', err);
      process.exit(1);
    }
    
    console.log('✅ HTTP server closed');
    console.log('👋 Server shutdown complete');
    process.exit(0);
  });

  // Force shutdown after timeout
  setTimeout(() => {
    console.error('⏰ Forced shutdown due to timeout');
    process.exit(1);
  }, 30000);
}

// Start the server if this file is run directly
if (require.main === module) {
  startServer();
}

module.exports = {
  startServer
};