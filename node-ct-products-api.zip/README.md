# Commercetools Products API

A professional, production-ready REST API for managing products through Commercetools, built with Express.js and following industry best practices.

## 🚀 Features

- **Professional Architecture**: Clean separation of concerns with controllers, services, and middleware
- **Comprehensive Error Handling**: Consistent error responses and logging
- **Input Validation**: Request validation with detailed error messages
- **Security**: Rate limiting, CORS, Helmet security headers
- **Performance**: Compression, clustering support for production
- **Development Tools**: Hot reload, logging, and development scripts
- **Commercetools Integration**: Full CRUD operations for products

## 📁 Project Structure

```
ct-products-api/
├── src/
│   ├── controllers/          # Request handlers
│   │   ├── productController.js
│   │   └── healthController.js
│   ├── services/             # Business logic
│   │   └── productService.js
│   ├── config/               # Configuration management
│   │   ├── index.js
│   │   └── commercetools.js
│   ├── middleware/           # Custom middleware
│   │   ├── errorHandler.js
│   │   └── validation.js
│   ├── routes/               # Route definitions
│   │   ├── index.js
│   │   ├── productRoutes.js
│   │   └── healthRoutes.js
│   ├── utils/                # Utility functions
│   │   └── httpResponse.js
│   └── app.js               # Express app configuration
├── scripts/                 # Deployment and dev scripts
│   ├── dev.js              # Development server
│   └── start.js            # Production cluster server
├── tests/                  # Test files (future)
├── docs/                   # Documentation
├── server.js              # Main entry point
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ct-products-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your Commercetools credentials
   ```

4. **Set up Commercetools credentials** in `.env`:
   ```env
   CT_PROJECT_KEY=your-project-key
   CT_CLIENT_ID=your-client-id
   CT_CLIENT_SECRET=your-client-secret
   CT_AUTH_URL=https://auth.europe-west1.gcp.commercetools.com
   CT_API_URL=https://api.europe-west1.gcp.commercetools.com
   CT_SCOPES=manage_products:your-project-key view_products:your-project-key
   ```

## 🚀 Usage

### Development Mode
```bash
npm run dev
```

### Production Mode
```bash
npm start
```

### Production with Clustering
```bash
npm run start:prod
```

## 📚 API Endpoints

### Health Check
- `GET /health` - Service health check
- `GET /api/v1/health` - Detailed health check

### Products
- `GET /api/v1/products/:id` - Get product by ID
- `POST /api/v1/products` - Create new product
- `PUT /api/v1/products/:id` - Update product
- `DELETE /api/v1/products/:id?version=X` - Delete product

## 📝 API Documentation

### Get Product by ID
```http
GET /api/v1/products/{id}
```

**Response:**
```json
{
  "success": true,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "data": {
    "id": "product-id",
    "version": 1,
    "name": { "en": "Product Name" },
    // ... other product fields
  }
}
```

### Create Product
```http
POST /api/v1/products
Content-Type: application/json

{
  "name": { "en": "New Product" },
  "productType": { "typeId": "product-type", "id": "product-type-id" },
  "slug": { "en": "new-product" }
}
```

### Update Product
```http
PUT /api/v1/products/{id}
Content-Type: application/json

{
  "version": 1,
  "actions": [
    {
      "action": "changeName",
      "name": { "en": "Updated Product Name" }
    }
  ]
}
```

### Delete Product
```http
DELETE /api/v1/products/{id}?version=1
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `PORT` | Server port | No | 3000 |
| `NODE_ENV` | Environment | No | development |
| `CT_PROJECT_KEY` | Commercetools project key | Yes | - |
| `CT_CLIENT_ID` | Commercetools client ID | Yes | - |
| `CT_CLIENT_SECRET` | Commercetools client secret | Yes | - |
| `CT_AUTH_URL` | Commercetools auth URL | Yes | - |
| `CT_API_URL` | Commercetools API URL | Yes | - |
| `CT_SCOPES` | Commercetools scopes (space-separated) | Yes | - |

## 🛡️ Security Features

- **Rate Limiting**: 100 requests per 15 minutes by default
- **CORS**: Configurable cross-origin resource sharing
- **Helmet**: Security headers protection
- **Input Validation**: Request validation and sanitization
- **Error Handling**: Secure error responses (no sensitive data exposure)

## 🎯 Performance Features

- **Compression**: Gzip compression for responses
- **Clustering**: Multi-process support for production
- **Caching**: Response compression and optimization
- **Connection Management**: Efficient database connection handling

## 📊 Monitoring

The API includes comprehensive logging and health checks:

- Request/response logging in development mode
- Error logging with stack traces (development only)
- Health check endpoints for load balancers
- Process monitoring for clustering

## 🧪 Testing

```bash
npm test
```

## 🚀 Deployment

### Docker (Optional)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

### Environment Setup
1. Set production environment variables
2. Use `npm run start:prod` for clustering
3. Configure reverse proxy (nginx/Apache)
4. Set up SSL certificates

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the ISC License.

## 🔗 Links

- [Commercetools Documentation](https://docs.commercetools.com/)
- [Express.js Documentation](https://expressjs.com/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

---

**Made with ❤️ for professional e-commerce development**