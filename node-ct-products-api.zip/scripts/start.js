#!/usr/bin/env node

/**
 * Production server startup script
 */

const cluster = require('cluster');
const os = require('os');
const { startServer } = require('../server');

const numWorkers = process.env.CLUSTER_WORKERS || os.cpus().length;

if (cluster.isMaster) {
  console.log('🚀 Starting production server with clustering...');
  console.log(`👥 Master process ${process.pid} starting ${numWorkers} workers`);

  // Fork workers
  for (let i = 0; i < numWorkers; i++) {
    cluster.fork();
  }

  // Handle worker events
  cluster.on('online', (worker) => {
    console.log(`👷 Worker ${worker.process.pid} is online`);
  });

  cluster.on('exit', (worker, code, signal) => {
    console.log(`💀 Worker ${worker.process.pid} died with code ${code} and signal ${signal}`);
    console.log('🔄 Restarting worker...');
    cluster.fork();
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('📱 SIGTERM received. Shutting down workers...');
    
    for (const id in cluster.workers) {
      cluster.workers[id].kill();
    }
  });

  process.on('SIGINT', () => {
    console.log('📱 SIGINT received. Shutting down workers...');
    
    for (const id in cluster.workers) {
      cluster.workers[id].kill();
    }
  });

} else {
  // Worker process
  startServer().catch((error) => {
    console.error('💥 Worker failed to start:', error);
    process.exit(1);
  });
}