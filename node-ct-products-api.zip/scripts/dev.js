#!/usr/bin/env node

/**
 * Development server with hot reload
 */

const nodemon = require('nodemon');
const path = require('path');

const script = nodemon({
  script: path.join(__dirname, '..', 'server.js'),
  ext: 'js,json',
  ignore: [
    'node_modules/',
    'tests/',
    'docs/',
    '.git/',
    '*.test.js',
    '*.spec.js'
  ],
  env: {
    NODE_ENV: 'development'
  },
  delay: 1000
});

script.on('start', () => {
  console.log('🔄 Development server started');
});

script.on('restart', (files) => {
  console.log('🔄 Development server restarted due to:', files);
});

script.on('quit', () => {
  console.log('👋 Development server stopped');
  process.exit();
});

script.on('crash', () => {
  console.log('💥 Development server crashed');
  process.exit(1);
});