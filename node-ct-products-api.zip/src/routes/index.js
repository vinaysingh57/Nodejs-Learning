const express = require('express');
const productRoutes = require('./productRoutes');
const healthRoutes = require('./healthRoutes');

/**
 * Main Routes Index
 * Combines all route modules
 */
function setupRoutes(app) {
  // API version prefix
  const apiRouter = express.Router();

  // Mount route modules
  apiRouter.use('/health', healthRoutes);
  apiRouter.use('/products', productRoutes);

  // Mount all routes under /api/v1
  app.use('/api/v1', apiRouter);

  // Health check at root for load balancers
  app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'ct-products-api' });
  });

  // API documentation redirect
  app.get('/docs', (req, res) => {
    res.redirect('/api/v1/health');
  });

  // Root endpoint
  app.get('/', (req, res) => {
    res.json({
      service: 'Commercetools Products API',
      version: '1.0.0',
      endpoints: {
        health: '/health',
        api: '/api/v1',
        docs: '/docs'
      }
    });
  });

  return app;
}

module.exports = setupRoutes;