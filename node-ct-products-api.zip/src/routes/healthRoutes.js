const express = require('express');
const HealthController = require('../controllers/healthController');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

/**
 * Health Routes
 * Base path: /health
 */

// GET /health - Health check endpoint
router.get('/', asyncHandler(HealthController.check));

module.exports = router;