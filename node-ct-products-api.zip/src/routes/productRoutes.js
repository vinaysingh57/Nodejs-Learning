const express = require('express');
const ProductController = require('../controllers/productController');
const { ValidationMiddleware, commonSchemas } = require('../middleware/validation');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

/**
 * Product Routes
 * Base path: /products
 */

// GET /products/:id - Get product by ID
router.get(
  '/:id',
  ValidationMiddleware.validateParams(commonSchemas.id),
  asyncHandler(ProductController.getById)
);

// POST /products - Create new product
router.post(
  '/',
  ValidationMiddleware.validateBody({
    name: {
      required: true,
      type: 'object'
    },
    productType: {
      required: true,
      type: 'object'
    },
    slug: {
      required: true,
      type: 'object'
    }
  }),
  asyncHandler(ProductController.create)
);

// PUT /products/:id - Update product
router.put(
  '/:id',
  ValidationMiddleware.validateParams(commonSchemas.id),
  ValidationMiddleware.validateBody({
    version: {
      required: true,
      type: 'number',
      integer: true,
      min: 1
    },
    actions: {
      required: true,
      type: 'object',
      custom: (value) => {
        if (!Array.isArray(value)) {
          return 'actions must be an array';
        }
        if (value.length === 0) {
          return 'actions array cannot be empty';
        }
        return null;
      }
    }
  }),
  asyncHandler(ProductController.update)
);

// DELETE /products/:id - Delete product
router.delete(
  '/:id',
  ValidationMiddleware.validateParams(commonSchemas.id),
  ValidationMiddleware.validateQuery({
    version: {
      required: true,
      type: 'string',
      custom: (value) => {
        const num = parseInt(value, 10);
        if (isNaN(num) || num < 1) {
          return 'version must be a positive integer';
        }
        return null;
      }
    }
  }),
  asyncHandler(ProductController.delete)
);

module.exports = router;