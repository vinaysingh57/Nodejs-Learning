const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const { config } = require('./config');
const setupRoutes = require('./routes');
const { 
  errorHandler, 
  notFoundHandler, 
  requestLogger 
} = require('./middleware/errorHandler');

/**
 * Create and configure Express application
 * @returns {Object} - Configured Express app
 */
function createApp() {
  const app = express();

  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Disable for API
    crossOriginEmbedderPolicy: false
  }));

  // CORS configuration
  app.use(cors({
    origin: config.cors.origin,
    credentials: config.cors.credentials,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.maxRequests,
    message: {
      success: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests, please try again later',
        status: 429
      }
    },
    standardHeaders: true,
    legacyHeaders: false
  });
  app.use(limiter);

  // General middleware
  app.use(compression()); // Compress responses
  app.use(express.json({ limit: '10mb' })); // Parse JSON bodies
  app.use(express.urlencoded({ extended: true, limit: '10mb' })); // Parse URL-encoded bodies

  // Request logging in development
  if (config.server.nodeEnv === 'development') {
    app.use(requestLogger);
  }

  // Setup routes
  setupRoutes(app);

  // 404 handler
  app.use(notFoundHandler);

  // Global error handler (must be last)
  app.use(errorHandler);

  return app;
}

module.exports = {
  createApp
};