/**
 * HTTP Response Utilities
 * Standardizes API responses across the application
 */

/**
 * Send successful response
 * @param {Object} res - Express response object
 * @param {*} data - Response data
 * @param {number} statusCode - HTTP status code (default: 200)
 * @param {string} message - Optional success message
 */
function sendSuccess(res, data = null, statusCode = 200, message = null) {
  const response = {
    success: true,
    timestamp: new Date().toISOString()
  };

  if (message) {
    response.message = message;
  }

  if (data !== null) {
    response.data = data;
  }

  return res.status(statusCode).json(response);
}

/**
 * Send error response
 * @param {Object} res - Express response object
 * @param {Object} error - Error object or Commercetools error
 * @param {string} customMessage - Custom error message override
 */
function sendError(res, error, customMessage = null) {
  const statusCode = error.statusCode || 500;
  const errorBody = error.body || { message: error.message || 'Unknown error' };

  const response = {
    success: false,
    timestamp: new Date().toISOString(),
    error: {
      code: errorBody.errors?.[0]?.code || error.code || 'INTERNAL_ERROR',
      message: customMessage || errorBody.message || 'An error occurred',
      status: statusCode
    }
  };

  // Include error details in development mode
  if (process.env.NODE_ENV === 'development') {
    response.error.details = errorBody.errors || errorBody;
    
    if (error.stack) {
      response.error.stack = error.stack;
    }
  }

  return res.status(statusCode).json(response);
}

/**
 * Send validation error response
 * @param {Object} res - Express response object
 * @param {Array|string} validationErrors - Validation error messages
 */
function sendValidationError(res, validationErrors) {
  const errors = Array.isArray(validationErrors) ? validationErrors : [validationErrors];

  const response = {
    success: false,
    timestamp: new Date().toISOString(),
    error: {
      code: 'VALIDATION_ERROR',
      message: 'Validation failed',
      status: 400,
      details: errors
    }
  };

  return res.status(400).json(response);
}

/**
 * Send not found response
 * @param {Object} res - Express response object
 * @param {string} resource - Resource that was not found
 */
function sendNotFound(res, resource = 'Resource') {
  const response = {
    success: false,
    timestamp: new Date().toISOString(),
    error: {
      code: 'NOT_FOUND',
      message: `${resource} not found`,
      status: 404
    }
  };

  return res.status(404).json(response);
}

/**
 * Send unauthorized response
 * @param {Object} res - Express response object
 * @param {string} message - Custom unauthorized message
 */
function sendUnauthorized(res, message = 'Unauthorized') {
  const response = {
    success: false,
    timestamp: new Date().toISOString(),
    error: {
      code: 'UNAUTHORIZED',
      message,
      status: 401
    }
  };

  return res.status(401).json(response);
}

module.exports = {
  sendSuccess,
  sendError,
  sendValidationError,
  sendNotFound,
  sendUnauthorized
};