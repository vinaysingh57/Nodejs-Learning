const { createCommercetoolsClient } = require('../config/commercetools');

class ProductService {
  constructor() {
    this.apiRoot = createCommercetoolsClient();
  }

  /**
   * Helper to execute requests and handle errors
   * @param {Object} request - Commercetools SDK request object
   * @returns {Promise<Object>} - Response body
   */
  async execute(request) {
    try {
      const response = await request.execute();
      return response.body;
    } catch (err) {
      console.error('Commercetools error:', err.statusCode, err.body || err);
      throw err;
    }
  }

  /**
   * Get product by ID
   * @param {string} id - Product ID
   * @returns {Promise<Object>} - Product data
   */
  async getProductById(id) {
    const request = this.apiRoot
      .products()
      .withId({ ID: id })
      .get();

    return this.execute(request);
  }

  /**
   * Create product
   * @param {Object} productDraft - Product draft object
   * @returns {Promise<Object>} - Created product data
   */
  async createProduct(productDraft) {
    const request = this.apiRoot
      .products()
      .post({
        body: productDraft
      });

    return this.execute(request);
  }

  /**
   * Update product - commercetools uses version + actions
   * @param {string} id - Product ID
   * @param {number} version - Current product version
   * @param {Array} actions - Array of update actions
   * @returns {Promise<Object>} - Updated product data
   */
  async updateProduct(id, version, actions) {
    const request = this.apiRoot
      .products()
      .withId({ ID: id })
      .post({
        body: {
          version,
          actions
        }
      });

    return this.execute(request);
  }

  /**
   * Delete product
   * @param {string} id - Product ID
   * @param {number} version - Current product version
   * @returns {Promise<Object>} - Deletion result
   */
  async deleteProduct(id, version) {
    const request = this.apiRoot
      .products()
      .withId({ ID: id })
      .delete({
        queryArgs: { version }
      });

    return this.execute(request);
  }

  /**
   * Search products with optional filters
   * @param {Object} searchParams - Search parameters
   * @returns {Promise<Object>} - Search results
   */
  async searchProducts(searchParams = {}) {
    const { limit = 20, offset = 0, where = null, sort = null } = searchParams;
    
    let request = this.apiRoot
      .products()
      .get({
        queryArgs: {
          limit,
          offset
        }
      });

    if (where) {
      request = request.where(where);
    }

    if (sort) {
      request = request.sort(sort);
    }

    return this.execute(request);
  }
}

// Export singleton instance
module.exports = new ProductService();