const { sendSuccess } = require('../utils/httpResponse');

class HealthController {
  /**
   * Health check endpoint
   * GET /health
   */
  static async check(req, res) {
    const healthStatus = {
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development'
    };

    sendSuccess(res, healthStatus);
  }
}

module.exports = HealthController;