const productService = require('../services/productService');
const { sendSuccess, sendError } = require('../utils/httpResponse');

class ProductController {
  /**
   * Get product by ID
   * GET /products/:id
   */
  static async getById(req, res) {
    const { id } = req.params;

    try {
      const product = await productService.getProductById(id);
      sendSuccess(res, product);
    } catch (error) {
      sendError(res, error);
    }
  }

  /**
   * Create a new product
   * POST /products
   */
  static async create(req, res) {
    const productDraft = req.body;

    try {
      const product = await productService.createProduct(productDraft);
      sendSuccess(res, product, 201);
    } catch (error) {
      sendError(res, error);
    }
  }

  /**
   * Update product
   * PUT /products/:id
   */
  static async update(req, res) {
    const { id } = req.params;
    const { version, actions } = req.body;

    // Basic validation
    if (typeof version !== 'number' || !Array.isArray(actions)) {
      return sendError(res, {
        statusCode: 400,
        body: {
          errors: [{
            code: 'INVALID_BODY',
            message: 'Body must have numeric "version" and array "actions".'
          }]
        }
      });
    }

    try {
      const product = await productService.updateProduct(id, version, actions);
      sendSuccess(res, product);
    } catch (error) {
      sendError(res, error);
    }
  }

  /**
   * Delete product
   * DELETE /products/:id?version=1
   */
  static async delete(req, res) {
    const { id } = req.params;
    const version = req.query.version ? Number(req.query.version) : undefined;

    if (!version) {
      return sendError(res, {
        statusCode: 400,
        body: {
          errors: [{
            code: 'VERSION_REQUIRED',
            message: 'You must pass "version" query parameter to delete a product.'
          }]
        }
      });
    }

    try {
      const result = await productService.deleteProduct(id, version);
      sendSuccess(res, result);
    } catch (error) {
      sendError(res, error);
    }
  }
}

module.exports = ProductController;