const { sendError } = require('../utils/httpResponse');

/**
 * Global error handling middleware
 * Catches all unhandled errors and formats them consistently
 */
function errorHandler(error, req, res, next) {
  // Log the error
  console.error('Unhandled error:', {
    message: error.message,
    stack: error.stack,
    url: req.url,
    method: req.method,
    timestamp: new Date().toISOString()
  });

  // Don't send error response if headers already sent
  if (res.headersSent) {
    return next(error);
  }

  // Send formatted error response
  sendError(res, error);
}

/**
 * 404 Not Found middleware
 * Handles requests to non-existent endpoints
 */
function notFoundHandler(req, res) {
  const response = {
    success: false,
    timestamp: new Date().toISOString(),
    error: {
      code: 'ENDPOINT_NOT_FOUND',
      message: `Cannot ${req.method} ${req.path}`,
      status: 404
    }
  };

  res.status(404).json(response);
}

/**
 * Request logging middleware
 * Logs incoming requests for debugging and monitoring
 */
function requestLogger(req, res, next) {
  const start = Date.now();
  
  // Log request start
  console.log(`→ ${req.method} ${req.url} - ${req.ip}`);

  // Override res.end to log response time
  const originalEnd = res.end;
  res.end = function(...args) {
    const duration = Date.now() - start;
    console.log(`← ${req.method} ${req.url} - ${res.statusCode} (${duration}ms)`);
    originalEnd.apply(this, args);
  };

  next();
}

/**
 * Async error handler wrapper
 * Wraps async route handlers to catch promise rejections
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = {
  errorHandler,
  notFoundHandler,
  requestLogger,
  asyncHandler
};