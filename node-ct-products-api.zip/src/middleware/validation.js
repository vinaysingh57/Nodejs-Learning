const { sendValidationError } = require('../utils/httpResponse');

/**
 * Validation middleware for request data
 */
class ValidationMiddleware {
  
  /**
   * Validate request body against schema
   * @param {Object} schema - Validation schema object
   * @returns {Function} - Express middleware function
   */
  static validateBody(schema) {
    return (req, res, next) => {
      const errors = ValidationMiddleware._validateObject(req.body, schema);
      
      if (errors.length > 0) {
        return sendValidationError(res, errors);
      }
      
      next();
    };
  }

  /**
   * Validate request parameters
   * @param {Object} schema - Validation schema object
   * @returns {Function} - Express middleware function
   */
  static validateParams(schema) {
    return (req, res, next) => {
      const errors = ValidationMiddleware._validateObject(req.params, schema);
      
      if (errors.length > 0) {
        return sendValidationError(res, errors);
      }
      
      next();
    };
  }

  /**
   * Validate request query parameters
   * @param {Object} schema - Validation schema object
   * @returns {Function} - Express middleware function
   */
  static validateQuery(schema) {
    return (req, res, next) => {
      const errors = ValidationMiddleware._validateObject(req.query, schema);
      
      if (errors.length > 0) {
        return sendValidationError(res, errors);
      }
      
      next();
    };
  }

  /**
   * Internal method to validate object against schema
   * @param {Object} obj - Object to validate
   * @param {Object} schema - Validation schema
   * @returns {Array} - Array of validation errors
   * @private
   */
  static _validateObject(obj, schema) {
    const errors = [];

    for (const [field, rules] of Object.entries(schema)) {
      const value = obj[field];

      // Check if field is required
      if (rules.required && (value === undefined || value === null || value === '')) {
        errors.push(`${field} is required`);
        continue;
      }

      // Skip further validation if field is not provided and not required
      if (value === undefined || value === null) {
        continue;
      }

      // Type validation
      if (rules.type && typeof value !== rules.type) {
        errors.push(`${field} must be of type ${rules.type}`);
        continue;
      }

      // String validations
      if (rules.type === 'string') {
        if (rules.minLength && value.length < rules.minLength) {
          errors.push(`${field} must be at least ${rules.minLength} characters long`);
        }

        if (rules.maxLength && value.length > rules.maxLength) {
          errors.push(`${field} must not exceed ${rules.maxLength} characters`);
        }

        if (rules.pattern && !rules.pattern.test(value)) {
          errors.push(`${field} format is invalid`);
        }
      }

      // Number validations
      if (rules.type === 'number') {
        if (rules.min && value < rules.min) {
          errors.push(`${field} must be at least ${rules.min}`);
        }

        if (rules.max && value > rules.max) {
          errors.push(`${field} must not exceed ${rules.max}`);
        }

        if (rules.integer && !Number.isInteger(value)) {
          errors.push(`${field} must be an integer`);
        }
      }

      // Array validations
      if (rules.type === 'object' && Array.isArray(value)) {
        if (rules.minItems && value.length < rules.minItems) {
          errors.push(`${field} must contain at least ${rules.minItems} items`);
        }

        if (rules.maxItems && value.length > rules.maxItems) {
          errors.push(`${field} must not contain more than ${rules.maxItems} items`);
        }
      }

      // Enum validation
      if (rules.enum && !rules.enum.includes(value)) {
        errors.push(`${field} must be one of: ${rules.enum.join(', ')}`);
      }

      // Custom validation function
      if (rules.custom && typeof rules.custom === 'function') {
        const customError = rules.custom(value, obj);
        if (customError) {
          errors.push(customError);
        }
      }
    }

    return errors;
  }
}

// Common validation schemas
const commonSchemas = {
  id: {
    id: {
      required: true,
      type: 'string',
      pattern: /^[a-zA-Z0-9\-_]+$/
    }
  },

  version: {
    version: {
      required: true,
      type: 'number',
      integer: true,
      min: 1
    }
  },

  pagination: {
    limit: {
      type: 'string',
      custom: (value) => {
        const num = parseInt(value, 10);
        if (isNaN(num) || num < 1 || num > 500) {
          return 'limit must be a number between 1 and 500';
        }
        return null;
      }
    },
    offset: {
      type: 'string',
      custom: (value) => {
        const num = parseInt(value, 10);
        if (isNaN(num) || num < 0) {
          return 'offset must be a non-negative number';
        }
        return null;
      }
    }
  }
};

module.exports = {
  ValidationMiddleware,
  commonSchemas
};