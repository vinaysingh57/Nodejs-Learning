const {
  createClient,
  createAuthForClientCredentialsFlow,
  createHttpClient
} = require('@commercetools/sdk-client-v2');
const { createApiBuilderFromCtpClient } = require('@commercetools/platform-sdk');
const { config } = require('./index');

/**
 * Creates and configures a Commercetools client
 * @returns {Object} - Configured Commercetools API root
 */
function createCommercetoolsClient() {
  const { projectKey, clientId, clientSecret, authUrl, apiUrl, scopes } =
    config.commercetools;

  try {
    // Middleware that gets auth token using client credentials
    const authMiddleware = createAuthForClientCredentialsFlow({
      host: authUrl,
      projectKey,
      credentials: {
        clientId,
        clientSecret
      },
      scopes,
      fetch
    });

    // Middleware that performs HTTP calls
    const httpMiddleware = createHttpClient({
      host: apiUrl,
      fetch
    });

    // Create the base client with both middlewares
    const ctpClient = createClient({
      middlewares: [authMiddleware, httpMiddleware]
    });

    // Create the API builder (apiRoot) for your project
    const apiRoot = createApiBuilderFromCtpClient(ctpClient).withProjectKey({
      projectKey
    });

    console.log(`✅ Commercetools client initialized for project: ${projectKey}`);
    return apiRoot;

  } catch (error) {
    console.error('❌ Failed to initialize Commercetools client:', error.message);
    throw new Error(`Commercetools client initialization failed: ${error.message}`);
  }
}

/**
 * Test Commercetools connection
 * @returns {Promise<boolean>} - Connection test result
 */
async function testCommercetoolsConnection() {
  try {
    const apiRoot = createCommercetoolsClient();
    
    // Try to fetch products with limit 1 (uses view_products scope which user has)
    const response = await apiRoot.products().get({
      queryArgs: { limit: 1 }
    }).execute();
    
    if (response.statusCode === 200) {
      console.log('✅ Commercetools connection test successful');
      return true;
    }
    
    console.log('⚠️ Commercetools connection test failed with status:', response.statusCode);
    return false;
    
  } catch (error) {
    console.error('❌ Commercetools connection test failed:', error.message);
    // Don't fail startup for connection test failures - just warn
    console.log('⚠️ Continuing startup despite connection test failure...');
    return true; // Return true to continue startup
  }
}

module.exports = {
  createCommercetoolsClient,
  testCommercetoolsConnection
};