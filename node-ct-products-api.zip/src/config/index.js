require('dotenv').config();

/**
 * Validates that required environment variable exists
 * @param {string} name - Environment variable name
 * @returns {string} - Environment variable value
 * @throws {Error} - If environment variable is missing
 */
function required(name) {
  if (!process.env[name]) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return process.env[name];
}

/**
 * Gets environment variable with optional default value
 * @param {string} name - Environment variable name
 * @param {*} defaultValue - Default value if not found
 * @returns {*} - Environment variable value or default
 */
function optional(name, defaultValue = null) {
  return process.env[name] || defaultValue;
}

const config = {
  // Server configuration
  server: {
    port: parseInt(optional('PORT', '3000'), 10),
    nodeEnv: optional('NODE_ENV', 'development'),
    host: optional('HOST', 'localhost')
  },

  // Commercetools configuration
  commercetools: {
    projectKey: required('CT_PROJECT_KEY'),
    clientId: required('CT_CLIENT_ID'),
    clientSecret: required('CT_CLIENT_SECRET'),
    authUrl: required('CT_AUTH_URL'),
    apiUrl: required('CT_API_URL'),
    scopes: required('CT_SCOPES').split(' ')
  },

  // Logging configuration
  logging: {
    level: optional('LOG_LEVEL', 'info'),
    format: optional('LOG_FORMAT', 'combined')
  },

  // CORS configuration
  cors: {
    origin: optional('CORS_ORIGIN', '*'),
    credentials: optional('CORS_CREDENTIALS', 'false') === 'true'
  },

  // Rate limiting
  rateLimit: {
    windowMs: parseInt(optional('RATE_LIMIT_WINDOW_MS', '900000'), 10), // 15 minutes
    maxRequests: parseInt(optional('RATE_LIMIT_MAX_REQUESTS', '100'), 10)
  }
};

// Validate configuration on startup
function validateConfig() {
  const requiredFields = [
    'commercetools.projectKey',
    'commercetools.clientId',
    'commercetools.clientSecret',
    'commercetools.authUrl',
    'commercetools.apiUrl'
  ];

  for (const field of requiredFields) {
    const value = field.split('.').reduce((obj, key) => obj?.[key], config);
    if (!value) {
      throw new Error(`Configuration validation failed: ${field} is required`);
    }
  }

  console.log('✅ Configuration validated successfully');
}

module.exports = {
  config,
  validateConfig
};