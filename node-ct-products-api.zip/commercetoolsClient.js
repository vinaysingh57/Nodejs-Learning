// commercetoolsClient.js
const {
  createClient,
  createAuthForClientCredentialsFlow,
  createHttpClient
} = require('@commercetools/sdk-client-v2');
const { createApiBuilderFromCtpClient } = require('@commercetools/platform-sdk');
const config = require('./config');

function createCommercetoolsClient() {
  const { projectKey, clientId, clientSecret, authUrl, apiUrl, scopes } =
    config.commercetools;

  // Middleware that gets auth token using client credentials
  const authMiddleware = createAuthForClientCredentialsFlow({
    host: authUrl,
    projectKey,
    credentials: {
      clientId,
      clientSecret
    },
    scopes,
    fetch
  });

  // Middleware that performs HTTP calls
  const httpMiddleware = createHttpClient({
    host: apiUrl,
    fetch
  });

  // Create the base client with both middlewares
  const ctpClient = createClient({
    middlewares: [authMiddleware, httpMiddleware]
  });

  // Create the API builder (apiRoot) for your project
  const apiRoot = createApiBuilderFromCtpClient(ctpClient).withProjectKey({
    projectKey
  });

  return apiRoot;
}

module.exports = {
  createCommercetoolsClient
};