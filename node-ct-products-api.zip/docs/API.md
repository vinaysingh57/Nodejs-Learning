# API Documentation

## Base URL
```
http://localhost:3000/api/v1
```

## Authentication
This API uses Commercetools client credentials flow. All authentication is handled internally via environment configuration.

## Response Format

### Success Response
```json
{
  "success": true,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "data": { ... }
}
```

### Error Response
```json
{
  "success": false,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description",
    "status": 400
  }
}
```

## Endpoints

### Health Check
**GET** `/health`

Returns service health status.

**Response:**
```json
{
  "success": true,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "data": {
    "status": "ok",
    "uptime": 12345,
    "environment": "development"
  }
}
```

### Products

#### Get Product by ID
**GET** `/products/{id}`

**Parameters:**
- `id` (string, required): Product ID

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "product-id",
    "version": 1,
    "name": { "en": "Product Name" },
    "productType": { ... },
    "slug": { "en": "product-slug" }
  }
}
```

#### Create Product
**POST** `/products`

**Request Body:**
```json
{
  "name": { "en": "Product Name" },
  "productType": {
    "typeId": "product-type",
    "id": "product-type-id"
  },
  "slug": { "en": "product-slug" }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "new-product-id",
    "version": 1,
    "name": { "en": "Product Name" },
    "productType": { ... },
    "slug": { "en": "product-slug" }
  }
}
```

#### Update Product
**PUT** `/products/{id}`

**Request Body:**
```json
{
  "version": 1,
  "actions": [
    {
      "action": "changeName",
      "name": { "en": "Updated Product Name" }
    }
  ]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "product-id",
    "version": 2,
    "name": { "en": "Updated Product Name" }
  }
}
```

#### Delete Product
**DELETE** `/products/{id}?version={version}`

**Parameters:**
- `id` (string, required): Product ID
- `version` (integer, required): Product version

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "product-id",
    "version": 2
  }
}
```

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `VALIDATION_ERROR` | 400 | Request validation failed |
| `NOT_FOUND` | 404 | Resource not found |
| `VERSION_REQUIRED` | 400 | Version parameter required |
| `INVALID_BODY` | 400 | Invalid request body format |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests |
| `CT_ERROR` | Various | Commercetools API error |
| `INTERNAL_ERROR` | 500 | Internal server error |

## Rate Limiting
- 100 requests per 15 minutes per IP address
- Applies to all endpoints
- Returns `429` status when exceeded