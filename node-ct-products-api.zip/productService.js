// productService.js
const { createCommercetoolsClient } = require('./commercetoolsClient');

const apiRoot = createCommercetoolsClient();

// Helper to run request and handle errors
async function execute(request) {
  try {
    const response = await request.execute();
    return response.body;
  } catch (err) {
    console.error('Commercetools error:', err.statusCode, err.body || err);
    throw err;
  }
}

// 1) Get product by ID
async function getProductById(id) {
  const request = apiRoot
    .products()
    .withId({ ID: id })
    .get();

  return execute(request);
}

// 2) Create product
async function createProduct(productDraft) {
  const request = apiRoot
    .products()
    .post({
      body: productDraft
    });

  return execute(request);
}

// 3) Update product - commercetools uses version + actions
async function updateProduct(id, version, actions) {
  const request = apiRoot
    .products()
    .withId({ ID: id })
    .post({
      body: {
        version,
        actions
      }
    });

  return execute(request);
}

// 4) Delete product
async function deleteProduct(id, version) {
  const request = apiRoot
    .products()
    .withId({ ID: id })
    .delete({
      queryArgs: { version }
    });

  return execute(request);
}

module.exports = {
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct
};