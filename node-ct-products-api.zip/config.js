// config.js
require('dotenv').config(); // Loads .env file

function required(name) {
  if (!process.env[name]) {
    throw new Error(`Missing environment variable: ${name}`);
  }
  return process.env[name];
}

const config = {
  port: process.env.PORT || 3000,
  commercetools: {
    projectKey: required('CT_PROJECT_KEY'),
    clientId: required('CT_CLIENT_ID'),
    clientSecret: required('CT_CLIENT_SECRET'),
    authUrl: required('CT_AUTH_URL'),
    apiUrl: required('CT_API_URL'),
    scopes: required('CT_SCOPES').split(' ')
  }
};

module.exports = config;