// app.js
const express = require('express');
const config = require('./config');
const {
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct
} = require('./productService');

const app = express();

// This allows Express to understand JSON body
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

//
// 1) GET /products/:id
//
app.get('/products/:id', async (req, res) => {
  const { id } = req.params; // read :id from URL

  try {
    const product = await getProductById(id);
    res.json(product); // return CT product as-is (for now)
  } catch (err) {
    handleCtError(err, res);
  }
});

//
// 2) POST /products
// Body should be a ProductDraft
//
app.post('/products', async (req, res) => {
  const productDraft = req.body;

  // TODO for later: validate productDraft

  try {
    const product = await createProduct(productDraft);
    res.status(201).json(product);
  } catch (err) {
    handleCtError(err, res);
  }
});

//
// 3) PUT /products/:id
// Body must contain: { version: number, actions: [] }
//
app.put('/products/:id', async (req, res) => {
  const { id } = req.params;
  const { version, actions } = req.body;

  // Basic validation
  if (typeof version !== 'number' || !Array.isArray(actions)) {
    return res.status(400).json({
      error: 'INVALID_BODY',
      message: 'Body must have numeric "version" and array "actions".'
    });
  }

  try {
    const product = await updateProduct(id, version, actions);
    res.json(product);
  } catch (err) {
    handleCtError(err, res);
  }
});

//
// 4) DELETE /products/:id?version=1
//
app.delete('/products/:id', async (req, res) => {
  const { id } = req.params;
  const version = req.query.version ? Number(req.query.version) : undefined;

  if (!version) {
    return res.status(400).json({
      error: 'VERSION_REQUIRED',
      message: 'You must pass "version" query parameter to delete a product.'
    });
  }

  try {
    const result = await deleteProduct(id, version);
    res.json(result);
  } catch (err) {
    handleCtError(err, res);
  }
});

// Simple CT error handler
function handleCtError(err, res) {
  const status = err.statusCode || 500;
  const body = err.body || { message: err.message || 'Unknown error' };

  res.status(status).json({
    error: body.errors?.[0]?.code || 'CT_ERROR',
    message: body.message || 'Error from commercetools',
    details: body.errors || body
  });
}

// Start the server
app.listen(config.port, () => {
  console.log(`Server listening on port ${config.port}`);
});